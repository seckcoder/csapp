


int bitAnd(int, int);
int test_bitAnd(int, int);
int tmin();
int test_tmin();
int negate(int);
int test_negate(int);
int allEvenBits();
int test_allEvenBits();
int bitCount(int);
int test_bitCount(int);
int logicalShift(int, int);
int test_logicalShift(int, int);
int isNegative(int);
int test_isNegative(int);
int isGreater(int, int);
int test_isGreater(int, int);
int isPower2(int);
int test_isPower2(int);
int fitsBits(int, int);
int test_fitsBits(int, int);
int conditional(int, int, int);
int test_conditional(int, int, int);
int greatestBitPos(int);
int test_greatestBitPos(int);
unsigned float_i2f(int);
unsigned test_float_i2f(int);
unsigned float_abs(unsigned);
unsigned test_float_abs(unsigned);
